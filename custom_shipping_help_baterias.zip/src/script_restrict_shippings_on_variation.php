<?php 

defined('ABSPATH') or die();
if(!function_exists('add_action')){
    die;
}
add_action('woocommerce_after_add_to_cart_form', 'script_restrict_shippings_on_variation');
function script_restrict_shippings_on_variation()
{
?>
<script>
    document.write('oi')
</script>


<?php 
}