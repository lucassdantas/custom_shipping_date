<?php 
// silence is golden 